/* Typewriter */
const instance = new Typewriter('#typewriter', {
    strings: ['novation ideas', 'digital innovation', 'business ideas'],
  	autoStart: true,
  	loop: true,
});